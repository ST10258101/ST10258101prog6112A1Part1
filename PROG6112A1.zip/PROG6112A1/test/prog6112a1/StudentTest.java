/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

package prog6112a1;

import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author Vinay
 */


public class StudentTest {

    @Test
    public void testSaveStudent() {
        Student student = new Student();

        // Set up student details
        student.setStudentId(123);
        student.setStudentName("John Doe");
        student.setStudentAge(20);
        student.setStudentEmail("john@example.com");
        student.setStudentCourse("Computer Science");

        // Save the student
        student.SaveStudent();

        // Search for the student and verify that the returned details are correct
        Student foundStudent = student.SearchStudent(123); // Use the correct ID here
        assertNotNull("Student should be found", foundStudent);
        assertEquals("Expected Name", "John Doe", foundStudent.studentName);
        assertEquals("Expected Age", 20, foundStudent.studentAge);
        assertEquals("Expected Email", "john@example.com", foundStudent.studentEmail);
        assertEquals("Expected Course", "Computer Science", foundStudent.studentCourse);
    }

    @Test
    public void testSearchStudent() {
        Student student = new Student();

        // Set up student details (replace these with real values)
        student.setStudentId(123);
        student.setStudentName("John Doe");
        student.setStudentAge(20);
        student.setStudentEmail("john@example.com");
        student.setStudentCourse("Computer Science");

        // Save the student
        student.SaveStudent();

        // Now, search for the student and verify that the returned details are correct
        Student foundStudent = student.SearchStudent(123); // Use the correct ID here
        assertNotNull("Student should be found", foundStudent);
        assertEquals("Expected Name", "John Doe", foundStudent.studentName);
        // Similarly, check other student details.
    }

    // ... Other test methods

    @Test
    public void testSearchStudent_StudentNotFound() {
        Student student = new Student();

        // Ensure that there are no students in the list
        assertNull("Student should not be found", student.SearchStudent("NonExistentId"));
    }

    @Test
    public void testDeleteStudent() {
        Student student = new Student();

        // Set up student details (replace these with real values)
        student.setStudentId(123);
        student.setStudentName("John Doe");
        student.setStudentAge(20);
        student.setStudentEmail("john@example.com");
        student.setStudentCourse("Computer Science");

        // Save the student
        student.SaveStudent();

        // Delete the student and verify that they are deleted
        student.DeleteStudent(123); // Use the correct ID here

        // Now, try to find the deleted student and ensure they are not found
        assertNull("Student should be deleted", student.SearchStudent(123)); // Use the correct ID here
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        Student student = new Student();

        // Ensure that there are no students in the list
        student.DeleteStudent("NonExistentId");
        assertNull("Student should not be found", student.SearchStudent("NonExistentId"));
    }

    @Test
    public void testStudentAgeValid() {
        Student student = new Student();

        // Set up a valid student age
        student.setStudentAge(18); // Use a valid age

        // Verify that the age is accepted
        assertTrue("Age should be valid", student.isStudentAgeValid());
    }

    @Test
    public void testStudentAgeInvalid() {
        Student student = new Student();

        // Set up an invalid student age
        student.setStudentAge(15); // Use an invalid age

        // Verify that the age is rejected
        assertFalse("Age should be invalid", student.isStudentAgeValid());
    }

    @Test
    public void testStudentAgeInvalidCharacter() {
        Student student = new Student();

        // Set up an age with an invalid character
        student.setStudentAge("abc"); // Use an invalid character

        // Verify that the age is rejected
        assertFalse("Age should be invalid", student.isStudentAgeValid());
    }
}

