/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112a1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author Vinay
 */
public class Student {
    ArrayList<String> studentDetails = new ArrayList<>();
     
    String[] arrID = new String[0];
    String[] arrName = new String[0];
    String[] arrAge = new String[0];
   //  int[] arrAge = new int[0];
    String[] arrEmail = new String[0];
    String[] arrCourse = new String[0];
    
 final Scanner kb = new Scanner(System.in);
    int choice;
    String start;
 void  Start(){
     System.out.println("""
     STUDENT MANAGEMENT APPLICATION
     ||||||||||||||||||||||||||||||""");
System.out.println("""
    Enter (1) to launch menu or any other key to exit >>>""");
start = kb.nextLine() ;
if (start.equals("1")){
    MainMenu();
} else {
    System.exit(0);
}

 }  
 void MainMenu(){
 System.out.println("""
    Please select one of the folowing menu items:
    (1)  Capture a new student.
    (2)  Search for a student.
    (3)  Delete a Student.
    (4)  Print Student Report.
    (5)  update student details.                                           
    (6)  Exit Application.""");  
 
 while (!kb.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid age (numbers only).");
                kb.next(); // Clear the invalid input
            }
 
 choice = kb.nextInt() ;
 switch (choice) {
     case 1:
         SaveStudent();  
         break;

     case 2:
         SearchStudent(); 
         break;
         
     case 3:
         DeleteStudent();
         break;

     case 4:
         StudentReport();
         break;

     case 5:
         UpdateStudent();
         break;
     case 6:
         ExitStudentApplication();
         break; 
     default:
         System.out.println("Invalid choice entered");
         MainMenu();
         break;
             
 }
}
 

void SaveStudent() {
    System.out.println("Capture a new student:");

    // Capture student details
    System.out.print("Enter student's ID: ");
    int id = kb.nextInt();
    kb.nextLine(); // Clear the newline character left in the buffer
    arrID = Arrays.copyOf(arrID, arrID.length + 1);
    arrID[arrID.length - 1] = " " + id; //STUDENT ID:

    System.out.print("Enter student's name: ");
    String name = kb.nextLine();
    arrName = Arrays.copyOf(arrName, arrName.length + 1);
    arrName[arrName.length - 1] = " " + name; //STUDENT Name:

    int age;
    do {
        System.out.print("Enter student's age: ");
        while (!kb.hasNextInt()) {
            System.out.println("Invalid input. Please enter a valid age (numbers only).");
            kb.next(); // Clear the invalid input
        }
        age = kb.nextInt();
        kb.nextLine(); // Clear the newline character left in the buffer

        if (age < 16) {
            System.out.println("Invalid age. Age must be 16 or older.");
        }
    } while (age < 16);
    arrAge = Arrays.copyOf(arrAge, arrAge.length + 1);
    arrAge[arrAge.length - 1] = " " + age; //STUDENT Age:
 
    System.out.print("Enter student's email: ");
    String email = kb.nextLine();
    arrEmail = Arrays.copyOf(arrEmail, arrEmail.length + 1);
    arrEmail[arrEmail.length - 1] = " " + email; //STUDENT Email:

    System.out.print("Enter student's course: ");
    String course = kb.nextLine();
    arrCourse = Arrays.copyOf(arrCourse, arrCourse.length + 1);
    arrCourse[arrCourse.length - 1] = " " + course; //STUDENT Course:

    // Inform the user that student details have been saved
    System.out.println("Student details have been successfully saved.");

    MainMenu(); // Back to the main menu after completion.
}


void SearchStudent() {
    System.out.println("Search for a student:");
    System.out.print("Enter student's ID: ");
    int searchId = kb.nextInt();
    kb.nextLine(); // Clear the newline character left in the buffer

    boolean found = false;

    for (int i = 0; i < arrID.length; i++) {
      //  if (arrID[i].contains(" " + searchId)) { //STUDENT ID:
            if (arrID[i].equals(" " + searchId)) { //STUDENT ID:
            found = true;

            System.out.println("Student found:");
            System.out.println("Student ID: " + arrID[i]);
            System.out.println("Student Name: " + arrName[i]);
            System.out.println("Student Age: " + arrAge[i]);
            System.out.println("Student Email: " + arrEmail[i]);
            System.out.println("Student Course: " + arrCourse[i]);
            System.out.println("----------------------------------------");
        }
    }

    if (!found) {
        System.out.println("Student with ID " + searchId + " not found.");
    }

    MainMenu(); // Back to the main menu after completion.
}




 void DeleteStudent() {
    System.out.println("Delete a student:");
    System.out.print("Enter student's ID to delete: ");
    int deleteId = kb.nextInt();
    kb.nextLine(); // Clear the newline character left in the buffer

    boolean found = false;
    int studentIndex = -1;

    for (int i = 0; i < arrID.length; i++) {
        if (arrID[i].equals(" " + deleteId)) { //STUDENT ID:
            found = true;
            studentIndex = i;
            break;
        }
    }

    if (found) {
        String studentDetails = "Student ID: " + arrID[studentIndex] + "\n" +
                "Student Name: " + arrName[studentIndex] + "\n" +
                "Student Age: " + arrAge[studentIndex] + "\n" +
                "Student Email: " + arrEmail[studentIndex] + "\n" +
                "Student Course: " + arrCourse[studentIndex];

        System.out.print("Are you sure you want to delete this student? (yes/no): ");
        String confirm = kb.next();
        if (confirm.equalsIgnoreCase("yes")) {
            // Delete the student
            arrID = removeElement(arrID, studentIndex);
            arrName = removeElement(arrName, studentIndex);
            arrAge = removeElement(arrAge, studentIndex);
            arrEmail = removeElement(arrEmail, studentIndex);
            arrCourse = removeElement(arrCourse, studentIndex);

            System.out.println("Student with ID " + deleteId + " has been deleted.");
        } else {
            System.out.println("Deletion canceled.");
        }
    } else {
        System.out.println("Student with ID " + deleteId + " not found.");
    }

    MainMenu(); // Back to the main menu after completion.
}


 void StudentReport() {
    StringBuilder allReports = new StringBuilder();

    if (arrID.length > 0) {
        for (int i = 0; i < arrID.length; i++) {
            allReports.append("Student ID: ").append(arrID[i]).append("\n");
            allReports.append("Student Name: ").append(arrName[i]).append("\n");
            allReports.append("Student Age: ").append(arrAge[i]).append("\n");
            allReports.append("Student Email: ").append(arrEmail[i]).append("\n");
            allReports.append("Student Course: ").append(arrCourse[i]).append("\n");
            allReports.append("==============================\n");
        }

        System.out.println("Captured Reports:\n\n" + allReports.toString());
    } else {
        System.out.println("No student reports found.");
    }

    MainMenu(); // Back to the main menu after displaying the report.
}


 void ExitStudentApplication() {
        System.out.println("Are you sure you want to exit? (yes/no): ");
        String confirm = kb.next();
        if (confirm.equalsIgnoreCase("yes")) {
            System.exit(0);
        } else if (confirm.equalsIgnoreCase("no")) {
            MainMenu();
        } else {
            System.out.println("Invalid choice. Exiting application.");
            System.exit(0);
        }
    }
 public static String[] removeElement(String[] array, int index) {
    String[] newArray = new String[array.length - 1];
    System.arraycopy(array, 0, newArray, 0, index);
    System.arraycopy(array, index + 1, newArray, index, array.length - index - 1);
    return newArray;
}
     private int[] removeElement(int[] array, int index) {
        int[] newArray = new int[array.length - 1];
        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index + 1, newArray, index, array.length - index - 1);
        return newArray;
    }
     void UpdateStudent() {
    System.out.println("Update student information:");
    System.out.print("Enter student's ID to update: ");
    int updateId = kb.nextInt();
    kb.nextLine(); // Clear the newline character left in the buffer

    boolean found = false;
    int studentIndex = -1;

    for (int i = 0; i < arrID.length; i++) {
        if (arrID[i].equals(" " + updateId)) { // Assuming student ID is unique
            found = true;
            studentIndex = i;
            break;
        }
    }

    if (found) {
        System.out.println("Current Student Details:");
        System.out.println("Student ID: " + arrID[studentIndex]);
        System.out.println("Student Name: " + arrName[studentIndex]);
        System.out.println("Student Age: " + arrAge[studentIndex]);
        System.out.println("Student Email: " + arrEmail[studentIndex]);
        System.out.println("Student Course: " + arrCourse[studentIndex]);
        System.out.println("----------------------------------------");

        // Capture updated student details
        System.out.print("Enter updated student's name (or press Enter to keep current value): ");
        String updatedName = kb.nextLine();
        if (!updatedName.isEmpty()) {
            arrName[studentIndex] = " " + updatedName; //STUDENT Name:
        }

        System.out.print("Enter updated student's age (or press Enter to keep current value): ");
        String updatedAgeStr = kb.nextLine();
        if (!updatedAgeStr.isEmpty()) {
            int updatedAge;
            try {
                updatedAge = Integer.parseInt(updatedAgeStr);
                if (updatedAge >= 16) {
                    arrAge[studentIndex] = " " + updatedAge; //STUDENT Age:
                } else {
                    System.out.println("Invalid age. Age must be 16 or older. The age won't be updated.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Age must be a number. The age won't be updated.");
            }
        }

        System.out.print("Enter updated student's email (or press Enter to keep current value): ");
        String updatedEmail = kb.nextLine();
        if (!updatedEmail.isEmpty()) {
            arrEmail[studentIndex] = " " + updatedEmail; //STUDENT Email:
        }

        System.out.print("Enter updated student's course (or press Enter to keep current value): ");
        String updatedCourse = kb.nextLine();
        if (!updatedCourse.isEmpty()) {
            arrCourse[studentIndex] = " " + updatedCourse; //STUDENT Course:
        }

        System.out.println("Student information has been updated.");
    } else {
        System.out.println("Student with ID " + updateId + " not found.");
    }

    MainMenu(); // Back to the main menu after completion.
}

    }


