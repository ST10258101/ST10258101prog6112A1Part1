/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112a1;

/**
 *
 * @author Vinay
 */
public class PROG6112A1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Student abc = new Student(); 
       // lr.welcomeMsg();
        abc.Start();
    }
    
}
